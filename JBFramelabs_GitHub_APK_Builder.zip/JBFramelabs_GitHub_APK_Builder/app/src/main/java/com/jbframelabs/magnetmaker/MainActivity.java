package com.jbframelabs.magnetmaker;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.InputStream;

public class MainActivity extends Activity {
    MagnetView magnetView;
    static final int PICK_IMAGE = 10;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,240,232));

        TextView title = new TextView(this);
        title.setText("JBFramelabs\nMagnet Maker");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(50,35,25));
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(24,24,24,16);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        magnetView = new MagnetView();
        root.addView(magnetView, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(12,10,12,10);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(Color.WHITE);

        Button upload = new Button(this);
        upload.setText("UPLOAD PHOTO");
        upload.setOnClickListener(v -> pickImage());
        bar.addView(upload, new LinearLayout.LayoutParams(0,60,1));

        Button fit = new Button(this);
        fit.setText("FIT");
        fit.setOnClickListener(v -> { magnetView.resetImage(); });
        bar.addView(fit, new LinearLayout.LayoutParams(0,60,1));

        root.addView(bar);
        setContentView(root);
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_IMAGE);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data);
        if(req == PICK_IMAGE && result == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
                InputStream in = getContentResolver().openInputStream(uri);
                Bitmap b = BitmapFactory.decodeStream(in);
                if(in != null) in.close();
                if(b != null) {
                    magnetView.setBitmap(b);
                } else {
                    Toast.makeText(this,"Could not load this image.",Toast.LENGTH_LONG).show();
                }
            } catch(Exception e) {
                try {
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    Bitmap b = BitmapFactory.decodeStream(in);
                    if(in != null) in.close();
                    if(b != null) magnetView.setBitmap(b);
                    else Toast.makeText(this,"Could not load this image.",Toast.LENGTH_LONG).show();
                } catch(Exception ex) {
                    Toast.makeText(this,"Image could not be opened.",Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    class MagnetView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap bitmap;
        float scale=1f, dx=0, dy=0;
        float lastX,lastY,oldDist;
        boolean moving=false;

        MagnetView() {
            super(MainActivity.this);
            p.setFilterBitmap(true);
            setBackgroundColor(Color.rgb(225,220,212));
        }

        void setBitmap(Bitmap b) {
            bitmap=b;
            resetImage();
            invalidate();
        }

        void resetImage() {
            if(bitmap != null) {
                float vw=getWidth(), vh=getHeight();
                float size=Math.min(vw,vh)*0.62f;
                scale=Math.max(size/bitmap.getWidth(),size/bitmap.getHeight());
            } else scale=1f;
            dx=dy=0;
            invalidate();
        }

        float magnetSize() { return Math.min(getWidth(),getHeight())*0.62f; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float s=magnetSize();
            float left=(getWidth()-s)/2f;
            float top=(getHeight()-s)/2f;

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            c.drawRect(left,top,left+s,top+s,p);

            if(bitmap != null) {
                c.save();
                Path clip=new Path();
                clip.addRect(left,top,left+s,top+s,Path.Direction.CW);
                c.clipPath(clip);

                float bw=bitmap.getWidth()*scale;
                float bh=bitmap.getHeight()*scale;
                float x=left+(s-bw)/2f+dx;
                float y=top+(s-bh)/2f+dy;
                c.drawBitmap(bitmap,null,new RectF(x,y,x+bw,y+bh),p);
                c.restore();
            }

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4);
            p.setColor(Color.RED);
            c.drawRect(left,top,left+s,top+s,p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.DKGRAY);
            p.setTextSize(28);
            c.drawText("50 × 50 mm",left,top+s+42,p);
            if(bitmap==null) {
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(30);
                c.drawText("Upload customer photo",getWidth()/2f,getHeight()/2f,p);
                p.setTextAlign(Paint.Align.LEFT);
            }
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX=e.getX(); lastY=e.getY(); moving=true; return true;
                case MotionEvent.ACTION_MOVE:
                    if(bitmap != null && e.getPointerCount()==1) {
                        dx += e.getX()-lastX; dy += e.getY()-lastY;
                        lastX=e.getX(); lastY=e.getY(); invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    moving=false; return true;
            }
            return true;
        }
    }
}
