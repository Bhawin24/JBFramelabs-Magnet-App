JBFramelabs Magnet Maker — GitHub APK Builder

This project is prepared so GitHub can build the Android APK without Android Studio on your PC.

IMPORTANT:
- Do NOT install Android Studio for this method.
- Do NOT download another 1.5 GB Android Studio file.

QUICK BUILD:
1. Create a GitHub account if you don't already have one.
2. Create a NEW repository. For the easiest route, make it Public and name it JBFramelabs-Magnet-Maker.
3. On the repository page choose Add file -> Upload files.
4. Upload ALL files and folders from this project, including the hidden .github folder.
5. Commit the files to the main branch.
6. Open the Actions tab.
7. Select "Build JBFramelabs APK".
8. Click "Run workflow".
9. Wait for the green check mark.
10. Open the completed workflow run and download the artifact named "JBFramelabs-Magnet-Maker-APK".
11. The artifact contains app-debug.apk.

If GitHub asks whether you trust the workflow, allow it because this is your own repository and workflow.

Current prototype:
- Upload photo
- 50 x 50 mm square preview
- Drag photo to reposition
- FIT button

Not yet included:
- A4 12-up layout
- 4 x 6 2-up layout
- 6 mm cut gap
- bleed settings
- zoom controls
- print-ready PDF

The first goal is to get the APK building successfully. Then the app can be expanded.
