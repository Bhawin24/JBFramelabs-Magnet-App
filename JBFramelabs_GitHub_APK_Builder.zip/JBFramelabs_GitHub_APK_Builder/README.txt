JBFramelabs Magnet Maker — Android Prototype 0.1

Purpose:
Photo -> 50 x 50 mm square magnet preview.

This is intentionally only the first prototype. It does NOT yet contain A4/4x6 PDF generation.

Build:
1. Install Android Studio on Windows.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

Test:
- Tap UPLOAD PHOTO.
- Choose a JPG/PNG from Gallery/files.
- The photo should appear inside the 50x50 mm preview.
- Drag the photo to reposition it.
- FIT resets the crop.

After this basic test works, the next version should add:
A4 = 12 magnets
4x6 = 2 magnets
6 mm cut gap
bleed
zoom
shape presets
print-ready PDF
